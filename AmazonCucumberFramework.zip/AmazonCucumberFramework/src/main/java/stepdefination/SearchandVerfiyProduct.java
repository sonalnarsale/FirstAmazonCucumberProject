package stepdefination;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import testbase.TestBase;


public class SearchandVerfiyProduct extends TestBase{
	
	@Given("^User is on Amazon homepage$")
	public void user_is_on_Amazon_homepage() {
		
		initialization();
		System.out.println("User is on Home Page");
		String title = driver.getTitle();
		Assert.assertEquals(title, "Amazon.com: Online Shopping for Electronics, Apparel, Computers, Books, DVDs & more");
	}

	@When("^User searches productID on the homepage$")
	public void user_searches_productID_on_the_homepage(DataTable data) throws Throwable {
		
		List<List<String>> list = data.raw();
		driver.findElement(By.xpath(prop.getProperty("xpath_textBox_Search"))).sendKeys(list.get(0).get(0));
		driver.findElement(By.xpath(prop.getProperty("xpath_button_Search"))).click();
	  
	}

	@Then("^User should get list of all available products$")
	public void user_should_get_list_of_all_available_products() {
		
		System.out.println("List of All Available Nikon Products :");
		List<WebElement>productList = driver.findElements(By.xpath(prop.getProperty("xpath_link_allProducts")));
		for(int i=0;i<productList.size();i++) {
			System.out.println(productList.get(i).getText());
		}
	   
	}

	@Then("^user is able to sort the results from Highest to Lowest Price$")
	public void user_is_able_to_sort_the_results_from_Highest_to_Lowest_Price() throws Throwable {
		
		driver.findElement(By.xpath(prop.getProperty("xpath_dropdown"))).click();
		driver.findElement(By.xpath(prop.getProperty("xpath_text_HighToLow"))).click(); 
	}

	@When("^User select second Product and click for details$")
	public void user_select_second_Product_and_click_for_details() {
	   
		driver.findElements(By.xpath(prop.getProperty("xpath_link_allProducts"))).get(1).click();
	}

	@Then("^User should be able to verify and assert the Product name$")
	public void user_should_be_able_to_verify_and_assert_the_Product_name() throws Throwable {
		
		String ProductName = driver.findElement(By.xpath(prop.getProperty("xpath_text_ProductTitle"))).getText();
		Assert.assertTrue(ProductName.contains("Nikon D850 FX"));
	}
	
}
