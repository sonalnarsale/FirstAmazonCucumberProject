$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/LENOVO/eclipse-workspace/AmazonCucumberFramework/src/main/java/feautures/login.feature");
formatter.feature({
  "line": 1,
  "name": "Search Nikon Product on the Amazon website.",
  "description": "",
  "id": "search-nikon-product-on-the-amazon-website.",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Validate if the guest user is able to verify and assert given product.",
  "description": "",
  "id": "search-nikon-product-on-the-amazon-website.;validate-if-the-guest-user-is-able-to-verify-and-assert-given-product.",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User is on Amazon homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User searches productID on the homepage",
  "rows": [
    {
      "cells": [
        "Nikon"
      ],
      "line": 7
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "User should get list of all available products",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "user is able to sort the results from Highest to Lowest Price",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "User select second Product and click for details",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "User should be able to verify and assert the Product name",
  "keyword": "Then "
});
formatter.match({
  "location": "SearchandVerfiyProduct.user_is_on_Amazon_homepage()"
});
formatter.result({
  "duration": 30918712800,
  "status": "passed"
});
formatter.match({
  "location": "SearchandVerfiyProduct.user_searches_productID_on_the_homepage(DataTable)"
});
formatter.result({
  "duration": 4329394900,
  "status": "passed"
});
formatter.match({
  "location": "SearchandVerfiyProduct.user_should_get_list_of_all_available_products()"
});
formatter.result({
  "duration": 231736400,
  "status": "passed"
});
formatter.match({
  "location": "SearchandVerfiyProduct.user_is_able_to_sort_the_results_from_Highest_to_Lowest_Price()"
});
formatter.result({
  "duration": 260557600,
  "status": "passed"
});
formatter.match({
  "location": "SearchandVerfiyProduct.user_select_second_Product_and_click_for_details()"
});
formatter.result({
  "duration": 4798427700,
  "status": "passed"
});
formatter.match({
  "location": "SearchandVerfiyProduct.user_should_be_able_to_verify_and_assert_the_Product_name()"
});
formatter.result({
  "duration": 26206700,
  "status": "passed"
});
});